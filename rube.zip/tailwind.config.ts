import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-inter)', 'Inter', 'system-ui', 'sans-serif']
      },
      colors: {
        rube: {
          bg: '#050711',
          panel: 'rgba(13, 18, 36, 0.72)',
          cyan: '#35F5FF',
          violet: '#9B5CFF',
          pink: '#FF4FD8',
          green: '#4CFFB3'
        }
      },
      boxShadow: {
        neon: '0 0 35px rgba(53,245,255,.22), 0 20px 80px rgba(155,92,255,.16)',
        panel: 'inset 0 1px 0 rgba(255,255,255,.11), 0 16px 55px rgba(0,0,0,.35)'
      },
      backdropBlur: {
        xs: '2px'
      },
      keyframes: {
        aurora: {
          '0%, 100%': { transform: 'translate3d(-6%, -3%, 0) scale(1)', opacity: '.75' },
          '50%': { transform: 'translate3d(4%, 5%, 0) scale(1.12)', opacity: '1' }
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% center' },
          '100%': { backgroundPosition: '200% center' }
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' }
        }
      },
      animation: {
        aurora: 'aurora 16s ease-in-out infinite',
        shimmer: 'shimmer 2.8s linear infinite',
        float: 'float 5s ease-in-out infinite'
      }
    }
  },
  plugins: []
};

export default config;
