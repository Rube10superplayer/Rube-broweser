# Rube Browser Mobile

A futuristic mobile-first browser-in-browser Progressive Web App built with Next.js, React, TailwindCSS, Framer Motion, service workers, local persistence, and optional Groq/OpenAI/Gemini AI integration.

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:3000` on a phone or use device emulation.

## AI keys

The app runs with a local demo assistant by default. To enable hosted AI calls, copy `.env.example` to `.env.local` and add a key for Groq, OpenAI, or Gemini.

## Important browser security reality

Rube renders sites in sandboxed iframes where possible. Many major websites intentionally block iframe embedding using `X-Frame-Options` or `Content-Security-Policy frame-ancestors`; a web app cannot bypass that safely. Rube detects the situation visually and provides external-open and search fallbacks. A true unrestricted webview requires a native app shell or server-side rendering/proxy architecture.
