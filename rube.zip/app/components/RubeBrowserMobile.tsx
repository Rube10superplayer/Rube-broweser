'use client';

import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { clearRubeStorage, loadArray, loadJson, saveJson } from '../lib/storage';
import { faviconFor, hostFromUrl, makeSuggestions, normalizeNavigation, searchUrl, trendingSearches } from '../lib/url';
import { usePwaInstall } from '../hooks/usePwaInstall';
import type { AiProvider, BrowserSettings, BrowserTab, ChatMessage, DownloadItem, HistoryEntry, SearchEngine, ThemeMode } from '../types/browser';

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: unknown) => void) | null;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
};

const DEFAULT_SETTINGS: BrowserSettings = {
  theme: 'dark',
  searchEngine: 'google',
  homepage: 'rube://newtab',
  fontScale: 1,
  animationIntensity: 1,
  privacyMode: false,
  blockPopups: true,
  aiProvider: 'demo',
  aiModel: ''
};

const newId = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function createTab(url = 'rube://newtab', incognito = false): BrowserTab {
  return {
    id: newId(),
    title: url === 'rube://newtab' ? 'New Tab' : hostFromUrl(url),
    url,
    favicon: faviconFor(url),
    canGoBack: false,
    canGoForward: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    progress: 0,
    loading: false,
    incognito,
    backStack: [],
    forwardStack: []
  };
}

const Icon = ({ name, className = '' }: { name: string; className?: string }) => {
  const paths: Record<string, string> = {
    back: 'M15 18l-6-6 6-6M9 12h12',
    forward: 'M9 18l6-6-6-6M15 12H3',
    home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
    plus: 'M12 5v14M5 12h14',
    tabs: 'M7 7h10a2 2 0 0 1 2 2v10H9a2 2 0 0 1-2-2zM5 15H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1',
    menu: 'M4 7h16M4 12h16M4 17h16',
    refresh: 'M20 12a8 8 0 1 1-2.34-5.66M20 4v6h-6',
    lock: 'M7 11V8a5 5 0 0 1 10 0v3M6 11h12v10H6z',
    ai: 'M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z',
    mic: 'M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3zM5 11a7 7 0 0 0 14 0M12 18v4',
    close: 'M6 6l12 12M18 6L6 18',
    search: 'M10.5 18a7.5 7.5 0 1 1 5.3-12.8 7.5 7.5 0 0 1-5.3 12.8zM16 16l5 5',
    download: 'M12 3v12m0 0l-5-5m5 5l5-5M4 21h16',
    shield: 'M12 3l8 3v6c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10V6z',
    settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 12H2m20 0h-2M12 4V2m0 20v-2M5.6 5.6L4.2 4.2m15.6 15.6-1.4-1.4M18.4 5.6l1.4-1.4M4.2 19.8l1.4-1.4',
    globe: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM2 12h20M12 2c3 3 4 6.5 4 10s-1 7-4 10c-3-3-4-6.5-4-10s1-7 4-10z',
    spark: 'M13 2L3 14h8l-1 8 10-12h-8z',
    external: 'M14 3h7v7M21 3l-9 9M21 14v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h6'
  };
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className || 'h-5 w-5'} aria-hidden="true">
      <path d={paths[name] || paths.spark} />
    </svg>
  );
};

const haptic = (ms = 12) => {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(ms);
};

function registerServiceWorker() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator && process.env.NODE_ENV !== 'development') {
    navigator.serviceWorker.register('/sw.js').catch(() => undefined);
  }
}

export default function RubeBrowserMobile() {
  const prefersReducedMotion = useReducedMotion();
  const { canInstall, installed, install } = usePwaInstall();
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const addressRef = useRef<HTMLInputElement | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [settings, setSettings] = useState<BrowserSettings>(DEFAULT_SETTINGS);
  const [tabs, setTabs] = useState<BrowserTab[]>([createTab()]);
  const [activeTabId, setActiveTabId] = useState('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [downloads, setDownloads] = useState<DownloadItem[]>([]);
  const [chat, setChat] = useState<ChatMessage[]>([
    { id: 'hello', role: 'assistant', content: 'Hi, I’m Rube AI. Ask me to open sites, search the web, summarize, translate, or control tabs.', createdAt: Date.now() }
  ]);
  const [address, setAddress] = useState('');
  const [inputFocused, setInputFocused] = useState(false);
  const [showTabs, setShowTabs] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showDownloads, setShowDownloads] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const [pull, setPull] = useState(0);
  const [embedHint, setEmbedHint] = useState(false);
  const touchStart = useRef<{ x: number; y: number; time: number } | null>(null);

  const activeTab = useMemo(() => tabs.find((tab) => tab.id === activeTabId) || tabs[0], [tabs, activeTabId]);
  const isNewTab = !activeTab || activeTab.url === 'rube://newtab';
  const animationScale = prefersReducedMotion ? 0 : settings.animationIntensity;

  useEffect(() => {
    const savedTabs = loadArray<BrowserTab>('rube.tabs', []);
    const cleanTabs = savedTabs.filter((tab) => !tab.incognito);
    const nextTabs = cleanTabs.length ? cleanTabs : [createTab()];
    setTabs(nextTabs);
    setActiveTabId(window.localStorage.getItem('rube.activeTab') || nextTabs[0].id);
    setSettings(loadJson<BrowserSettings>('rube.settings', DEFAULT_SETTINGS));
    setHistory(loadArray<HistoryEntry>('rube.history', []));
    setDownloads(loadArray<DownloadItem>('rube.downloads', []));
    setChat(loadArray<ChatMessage>('rube.chat', [
      { id: 'hello', role: 'assistant', content: 'Hi, I’m Rube AI. Ask me to open sites, search the web, summarize, translate, or control tabs.', createdAt: Date.now() }
    ]));
    registerServiceWorker();
    setInitialized(true);
  }, []);

  useEffect(() => {
    if (activeTab && !inputFocused) setAddress(activeTab.url === 'rube://newtab' ? '' : activeTab.url);
  }, [activeTab?.id, activeTab?.url, inputFocused]);

  useEffect(() => {
    if (!initialized) return;
    saveJson('rube.settings', settings);
  }, [settings, initialized]);

  useEffect(() => {
    if (!initialized) return;
    saveJson('rube.tabs', tabs.filter((tab) => !tab.incognito).slice(-40));
    if (activeTabId) window.localStorage.setItem('rube.activeTab', activeTabId);
  }, [tabs, activeTabId, initialized]);

  useEffect(() => {
    if (!initialized) return;
    saveJson('rube.history', history.slice(0, 250));
  }, [history, initialized]);

  useEffect(() => {
    if (!initialized) return;
    saveJson('rube.downloads', downloads.slice(0, 100));
  }, [downloads, initialized]);

  useEffect(() => {
    if (!initialized) return;
    saveJson('rube.chat', chat.slice(-80));
  }, [chat, initialized]);

  useEffect(() => {
    if (!activeTab?.loading) return;
    setEmbedHint(false);
    const progress = window.setInterval(() => {
      setTabs((current) => current.map((tab) => {
        if (tab.id !== activeTab.id || !tab.loading) return tab;
        const next = Math.min(91, (tab.progress || 8) + Math.random() * 9);
        return { ...tab, progress: next };
      }));
    }, 260);
    const hint = window.setTimeout(() => setEmbedHint(true), 5500);
    return () => {
      window.clearInterval(progress);
      window.clearTimeout(hint);
    };
  }, [activeTab?.id, activeTab?.loading]);

  useEffect(() => {
    if (!downloads.some((item) => item.state === 'downloading')) return;
    const timer = window.setInterval(() => {
      setDownloads((items) => items.map((item) => {
        if (item.state !== 'downloading') return item;
        const progress = Math.min(100, item.progress + Math.random() * 12 + 4);
        return { ...item, progress, state: progress >= 100 ? 'complete' : 'downloading' };
      }));
    }, 700);
    return () => window.clearInterval(timer);
  }, [downloads]);

  const updateTab = useCallback((id: string, patch: Partial<BrowserTab> | ((tab: BrowserTab) => BrowserTab)) => {
    setTabs((current) => current.map((tab) => {
      if (tab.id !== id) return tab;
      const next = typeof patch === 'function' ? patch(tab) : { ...tab, ...patch };
      return {
        ...next,
        canGoBack: !!next.backStack?.length,
        canGoForward: !!next.forwardStack?.length,
        updatedAt: Date.now()
      };
    }));
  }, []);

  const addHistory = useCallback((url: string, title: string, tab?: BrowserTab) => {
    if (settings.privacyMode || tab?.incognito || url.startsWith('rube://')) return;
    setHistory((items) => [{ id: newId(), url, title, visitedAt: Date.now() }, ...items.filter((item) => item.url !== url)].slice(0, 250));
  }, [settings.privacyMode]);

  const navigate = useCallback((input: string, targetTabId = activeTabId, replace = false) => {
    const tab = tabs.find((item) => item.id === targetTabId) || activeTab;
    if (!tab) return;
    if (input.trim().toLowerCase().startsWith('ai:')) {
      setShowAI(true);
      setAiPrompt(input.replace(/^ai:/i, '').trim());
      return;
    }
    const url = normalizeNavigation(input, settings.searchEngine);
    haptic();
    const title = url === 'rube://newtab' ? 'New Tab' : hostFromUrl(url);
    updateTab(tab.id, (current) => {
      const backStack = replace || current.url === url || current.url === 'rube://newtab' ? current.backStack || [] : [...(current.backStack || []), current.url].slice(-50);
      return {
        ...current,
        title,
        url,
        favicon: faviconFor(url),
        loading: url !== 'rube://newtab',
        progress: url === 'rube://newtab' ? 0 : 7,
        backStack,
        forwardStack: replace ? current.forwardStack || [] : []
      };
    });
    addHistory(url, title, tab);
    setInputFocused(false);
    setShowTabs(false);
  }, [activeTab, activeTabId, addHistory, settings.searchEngine, tabs, updateTab]);

  const submitAddress = (event?: FormEvent) => {
    event?.preventDefault();
    if (!address.trim()) {
      navigate(settings.homepage || 'rube://newtab');
      return;
    }
    navigate(address);
    addressRef.current?.blur();
  };

  const addTab = useCallback((url = settings.homepage || 'rube://newtab', incognito = settings.privacyMode) => {
    const normalized = url === 'rube://newtab' ? url : normalizeNavigation(url, settings.searchEngine);
    const tab = createTab(normalized, incognito);
    tab.loading = normalized !== 'rube://newtab';
    tab.progress = tab.loading ? 6 : 0;
    setTabs((items) => [...items, tab]);
    setActiveTabId(tab.id);
    setShowTabs(false);
    haptic(18);
  }, [settings.homepage, settings.privacyMode, settings.searchEngine]);

  const closeTab = useCallback((id: string) => {
    setTabs((items) => {
      const index = items.findIndex((tab) => tab.id === id);
      const remaining = items.filter((tab) => tab.id !== id);
      if (!remaining.length) {
        const tab = createTab();
        setActiveTabId(tab.id);
        return [tab];
      }
      if (id === activeTabId) {
        const next = remaining[Math.max(0, index - 1)] || remaining[0];
        setActiveTabId(next.id);
      }
      return remaining;
    });
    haptic(10);
  }, [activeTabId]);

  const goBack = useCallback(() => {
    if (!activeTab) return;
    if (activeTab.backStack?.length) {
      const previous = activeTab.backStack[activeTab.backStack.length - 1];
      updateTab(activeTab.id, (tab) => ({
        ...tab,
        url: previous,
        title: previous === 'rube://newtab' ? 'New Tab' : hostFromUrl(previous),
        favicon: faviconFor(previous),
        loading: previous !== 'rube://newtab',
        progress: previous === 'rube://newtab' ? 0 : 7,
        backStack: (tab.backStack || []).slice(0, -1),
        forwardStack: [tab.url, ...(tab.forwardStack || [])].slice(0, 50)
      }));
    } else {
      try { iframeRef.current?.contentWindow?.history.back(); } catch { /* ignored */ }
    }
    haptic(9);
  }, [activeTab, updateTab]);

  const goForward = useCallback(() => {
    if (!activeTab) return;
    if (activeTab.forwardStack?.length) {
      const next = activeTab.forwardStack[0];
      updateTab(activeTab.id, (tab) => ({
        ...tab,
        url: next,
        title: next === 'rube://newtab' ? 'New Tab' : hostFromUrl(next),
        favicon: faviconFor(next),
        loading: next !== 'rube://newtab',
        progress: next === 'rube://newtab' ? 0 : 7,
        backStack: [...(tab.backStack || []), tab.url].slice(-50),
        forwardStack: (tab.forwardStack || []).slice(1)
      }));
    } else {
      try { iframeRef.current?.contentWindow?.history.forward(); } catch { /* ignored */ }
    }
    haptic(9);
  }, [activeTab, updateTab]);

  const refresh = useCallback(() => {
    if (!activeTab) return;
    if (activeTab.url === 'rube://newtab') {
      setPull(0);
      haptic(16);
      return;
    }
    updateTab(activeTab.id, { loading: true, progress: 5 });
    setPull(0);
    haptic(16);
  }, [activeTab, updateTab]);

  const home = () => navigate(settings.homepage || 'rube://newtab');

  const openExternal = () => {
    if (activeTab && activeTab.url !== 'rube://newtab') window.open(activeTab.url, '_blank', 'noopener,noreferrer');
  };

  const onFrameLoad = () => {
    if (!activeTab) return;
    let title = hostFromUrl(activeTab.url);
    try {
      const docTitle = iframeRef.current?.contentDocument?.title;
      if (docTitle) title = docTitle;
    } catch {
      // Cross-origin frames cannot be inspected. This is expected and safe.
    }
    updateTab(activeTab.id, { title, loading: false, progress: 100 });
    setTimeout(() => updateTab(activeTab.id, { progress: 0 }), 520);
  };

  const extractPageText = () => {
    try {
      const text = iframeRef.current?.contentDocument?.body?.innerText || '';
      return text.slice(0, 12000);
    } catch {
      return '';
    }
  };

  const askAI = useCallback(async (prompt: string) => {
    if (!prompt.trim() || aiBusy) return;
    setShowAI(true);
    setAiPrompt('');
    const userMessage: ChatMessage = { id: newId(), role: 'user', content: prompt, createdAt: Date.now() };
    setChat((items) => [...items, userMessage]);
    setAiBusy(true);
    try {
      const pageText = /summari|translate|explain|page|read/i.test(prompt) ? extractPageText() : '';
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          provider: settings.aiProvider,
          apiKey: settings.aiApiKey,
          model: settings.aiModel,
          prompt,
          url: activeTab?.url,
          pageText,
          messages: chat.filter((m) => m.role !== 'system').slice(-8).map(({ role, content }) => ({ role, content }))
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'AI request failed');
      const assistant: ChatMessage = { id: newId(), role: 'assistant', content: data.text, createdAt: Date.now() };
      setChat((items) => [...items, assistant]);
    } catch (error) {
      setChat((items) => [...items, { id: newId(), role: 'assistant', content: `AI error: ${error instanceof Error ? error.message : 'Request failed'}`, createdAt: Date.now() }]);
    } finally {
      setAiBusy(false);
    }
  }, [activeTab?.url, aiBusy, chat, settings.aiApiKey, settings.aiModel, settings.aiProvider]);

  const processVoiceCommand = useCallback((raw: string) => {
    const command = raw.trim();
    const lower = command.toLowerCase();
    if (!command) return;
    if (lower.startsWith('open ')) navigate(command.slice(5));
    else if (lower.startsWith('search ')) navigate(command.slice(7));
    else if (lower.includes('close tab')) closeTab(activeTabId);
    else if (lower.includes('go back')) goBack();
    else if (lower.includes('go forward')) goForward();
    else if (lower.includes('new tab')) addTab('rube://newtab');
    else if (lower.includes('summarize')) askAI('Summarize this page in concise bullets.');
    else navigate(command);
  }, [activeTabId, addTab, askAI, closeTab, goBack, goForward, navigate]);

  const startVoice = () => {
    const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Speech) {
      setShowAI(true);
      setChat((items) => [...items, { id: newId(), role: 'assistant', content: 'Voice recognition is not available in this browser. Try Chrome/Android or Safari with speech support enabled.', createdAt: Date.now() }]);
      return;
    }
    const recognition = new Speech();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onstart = () => setVoiceListening(true);
    recognition.onend = () => setVoiceListening(false);
    recognition.onerror = () => setVoiceListening(false);
    recognition.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript || '';
      processVoiceCommand(transcript);
    };
    recognitionRef.current = recognition;
    recognition.start();
    haptic(20);
  };

  const addDownload = (url = activeTab?.url || 'https://example.com/file') => {
    const name = `${hostFromUrl(url).replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'download'}-${Date.now().toString().slice(-4)}.html`;
    setDownloads((items) => [{ id: newId(), filename: name, url, progress: 0, state: 'downloading', createdAt: Date.now() }, ...items]);
    setShowDownloads(true);
    haptic(18);
  };

  const onTouchStart = (event: React.TouchEvent) => {
    const touch = event.touches[0];
    touchStart.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
  };

  const onTouchMove = (event: React.TouchEvent) => {
    if (!touchStart.current) return;
    const touch = event.touches[0];
    const dy = touch.clientY - touchStart.current.y;
    const dx = touch.clientX - touchStart.current.x;
    if (Math.abs(dx) < 30 && dy > 0 && touchStart.current.y < 120) setPull(Math.min(82, dy * 0.45));
  };

  const onTouchEnd = (event: React.TouchEvent) => {
    if (!touchStart.current) return;
    const changed = event.changedTouches[0];
    const dx = changed.clientX - touchStart.current.x;
    const dy = changed.clientY - touchStart.current.y;
    const dt = Date.now() - touchStart.current.time;
    if (pull > 58) refresh();
    else setPull(0);
    if (Math.abs(dx) > 92 && Math.abs(dx) > Math.abs(dy) * 1.5 && dt < 650) {
      if (dx > 0) goBack();
      else goForward();
    }
    touchStart.current = null;
  };

  const suggestions = useMemo(() => makeSuggestions(address, history.map((item) => item.title || item.url)), [address, history]);

  const themeClass = {
    dark: 'from-[#050711] via-[#080d1c] to-[#060718]',
    midnight: 'from-black via-[#071121] to-[#111022]',
    aurora: 'from-[#06131d] via-[#16112c] to-[#19071d]',
    light: 'from-[#dfefff] via-[#f6f2ff] to-[#fff3fb] text-slate-950'
  }[settings.theme];

  return (
    <main className={`relative h-[100dvh] w-screen overflow-hidden bg-gradient-to-br ${themeClass}`} style={{ fontSize: `${settings.fontScale}rem` }}>
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 top-[-8rem] h-80 w-80 rounded-full bg-rube-cyan/20 blur-3xl animate-aurora" />
        <div className="absolute -right-24 top-20 h-96 w-96 rounded-full bg-rube-pink/15 blur-3xl animate-aurora [animation-delay:-7s]" />
        <div className="absolute bottom-[-12rem] left-1/3 h-96 w-96 rounded-full bg-rube-violet/20 blur-3xl animate-aurora [animation-delay:-11s]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.035)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.025)_1px,transparent_1px)] bg-[size:48px_48px] opacity-30" />
      </div>

      <section className="relative z-10 mx-auto flex h-full max-w-5xl flex-col overflow-hidden md:px-3 md:py-3">
        <TopBar
          activeTab={activeTab}
          address={address}
          setAddress={setAddress}
          onSubmit={submitAddress}
          onFocus={() => setInputFocused(true)}
          onBlur={() => setTimeout(() => setInputFocused(false), 130)}
          inputRef={addressRef}
          onRefresh={refresh}
          onAI={() => setShowAI(true)}
          onTabs={() => setShowTabs(true)}
          onMenu={() => setShowMenu(true)}
          tabCount={tabs.length}
          secure={!!activeTab?.url?.startsWith('https://')}
          voiceListening={voiceListening}
          onVoice={startVoice}
        />

        <AnimatePresence>
          {inputFocused && (
            <SearchSuggestions
              suggestions={suggestions}
              onPick={(value) => {
                if (value.startsWith('ai:')) askAI(value.slice(3));
                else navigate(value);
              }}
            />
          )}
        </AnimatePresence>

        <div className="pointer-events-none absolute left-4 right-4 top-[calc(var(--safe-top)+74px)] z-30 h-1 overflow-hidden rounded-full bg-white/5">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-rube-cyan via-rube-violet to-rube-pink shadow-[0_0_18px_rgba(53,245,255,.75)]"
            animate={{ width: `${activeTab?.progress || 0}%`, opacity: activeTab?.progress ? 1 : 0 }}
            transition={{ duration: .22 }}
          />
        </div>

        <section
          className="browser-frame relative min-h-0 flex-1 overflow-hidden px-3 pb-[calc(var(--safe-bottom)+86px)] pt-2 md:pb-3"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          <motion.div
            className="absolute left-1/2 top-2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/10 bg-black/40 px-4 py-2 text-xs text-white/75 backdrop-blur-xl"
            animate={{ y: pull ? pull / 2 : -64, opacity: pull ? 1 : 0 }}
          >
            <Icon name="refresh" className={`h-4 w-4 ${pull > 58 ? 'text-rube-cyan' : ''}`} /> {pull > 58 ? 'Release to refresh' : 'Pull to refresh'}
          </motion.div>

          <AnimatePresence mode="wait">
            {isNewTab ? (
              <motion.div
                key="newtab"
                initial={{ opacity: 0, scale: .985, y: 16 * animationScale }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: .99, y: -10 * animationScale }}
                transition={{ duration: .28 * Math.max(animationScale, .45), ease: 'easeOut' }}
                className="h-full overflow-y-auto rounded-[2rem] glass no-scrollbar"
              >
                <NewTabView
                  onNavigate={navigate}
                  onAI={(prompt) => askAI(prompt)}
                  history={history}
                  installed={installed}
                  canInstall={canInstall}
                  onInstall={install}
                />
              </motion.div>
            ) : (
              <motion.div
                key={activeTab?.id + activeTab?.updatedAt}
                initial={{ opacity: 0, scale: .985, x: 18 * animationScale }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: .99, x: -14 * animationScale }}
                transition={{ duration: .24 * Math.max(animationScale, .45), ease: 'easeOut' }}
                className="relative h-full overflow-hidden rounded-[1.65rem] border border-white/10 bg-white shadow-2xl"
              >
                <iframe
                  ref={iframeRef}
                  title={activeTab?.title || 'Rube tab'}
                  src={activeTab?.url}
                  onLoad={onFrameLoad}
                  sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation allow-downloads"
                  referrerPolicy="strict-origin-when-cross-origin"
                  className="h-full w-full bg-white"
                />
                <AnimatePresence>
                  {activeTab?.loading && (
                    <motion.div className="pointer-events-none absolute inset-x-0 top-0 flex justify-center p-4" initial={{ opacity: 0, y: -18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -18 }}>
                      <div className="glass flex items-center gap-3 rounded-full px-4 py-2 text-xs text-white/80">
                        <span className="h-2 w-2 animate-pulse rounded-full bg-rube-cyan shadow-[0_0_16px_#35F5FF]" /> Loading {hostFromUrl(activeTab.url)}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                {embedHint && activeTab?.loading && <EmbedHint url={activeTab.url} onExternal={openExternal} onSearch={() => navigate(hostFromUrl(activeTab.url))} />}
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        <BottomNav
          canGoBack={!!activeTab?.canGoBack}
          canGoForward={!!activeTab?.canGoForward}
          onBack={goBack}
          onForward={goForward}
          onHome={home}
          onNewTab={() => addTab('rube://newtab')}
          onTabs={() => setShowTabs(true)}
        />
      </section>

      <AnimatePresence>
        {showTabs && (
          <TabsGrid
            tabs={tabs}
            activeTabId={activeTabId}
            onSelect={(id) => { setActiveTabId(id); setShowTabs(false); haptic(12); }}
            onClose={closeTab}
            onAdd={() => addTab('rube://newtab')}
            onDismiss={() => setShowTabs(false)}
          />
        )}
        {showAI && (
          <AIPanel
            chat={chat}
            prompt={aiPrompt}
            setPrompt={setAiPrompt}
            busy={aiBusy}
            onAsk={askAI}
            onClose={() => setShowAI(false)}
            onCommand={processVoiceCommand}
            onVoice={startVoice}
            voiceListening={voiceListening}
            provider={settings.aiProvider}
          />
        )}
        {showSettings && (
          <SettingsSheet
            settings={settings}
            setSettings={setSettings}
            onClose={() => setShowSettings(false)}
            onClear={() => {
              clearRubeStorage();
              setHistory([]);
              setDownloads([]);
              setTabs([createTab()]);
              setChat([{ id: 'hello', role: 'assistant', content: 'Clean slate. History, tabs, downloads, and chat were cleared.', createdAt: Date.now() }]);
              setShowSettings(false);
            }}
          />
        )}
        {showDownloads && (
          <DownloadsSheet
            downloads={downloads}
            setDownloads={setDownloads}
            onClose={() => setShowDownloads(false)}
          />
        )}
        {showMenu && (
          <MenuSheet
            onClose={() => setShowMenu(false)}
            onSettings={() => { setShowMenu(false); setShowSettings(true); }}
            onDownloads={() => { setShowMenu(false); setShowDownloads(true); }}
            onInstall={install}
            canInstall={canInstall}
            installed={installed}
            onNewIncognito={() => { addTab('rube://newtab', true); setShowMenu(false); }}
            onDownload={() => { addDownload(); setShowMenu(false); }}
            onExternal={openExternal}
            currentUrl={activeTab?.url || ''}
          />
        )}
      </AnimatePresence>
    </main>
  );
}

function TopBar({
  activeTab,
  address,
  setAddress,
  onSubmit,
  onFocus,
  onBlur,
  inputRef,
  onRefresh,
  onAI,
  onTabs,
  onMenu,
  tabCount,
  secure,
  voiceListening,
  onVoice
}: {
  activeTab?: BrowserTab;
  address: string;
  setAddress: (value: string) => void;
  onSubmit: (event?: FormEvent) => void;
  onFocus: () => void;
  onBlur: () => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onRefresh: () => void;
  onAI: () => void;
  onTabs: () => void;
  onMenu: () => void;
  tabCount: number;
  secure: boolean;
  voiceListening: boolean;
  onVoice: () => void;
}) {
  return (
    <header className="relative z-40 px-3 pt-[calc(var(--safe-top)+10px)] md:px-0">
      <div className="glass flex items-center gap-2 rounded-[1.6rem] p-2">
        <button aria-label="Refresh" onClick={onRefresh} className="touch-pop grid h-10 w-10 place-items-center rounded-full bg-white/7 text-white/80 transition hover:bg-white/12">
          <Icon name="refresh" />
        </button>
        <form onSubmit={onSubmit} className="min-w-0 flex-1">
          <label className="group flex h-11 items-center gap-2 rounded-full border border-white/10 bg-black/25 px-3 shadow-inner shadow-black/20 transition focus-within:border-rube-cyan/50 focus-within:bg-black/35 focus-within:shadow-[0_0_22px_rgba(53,245,255,.12)]">
            <Icon name={secure ? 'lock' : 'globe'} className={`h-4 w-4 ${secure ? 'text-rube-green' : 'text-white/45'}`} />
            <input
              ref={inputRef}
              value={address}
              onChange={(event) => setAddress(event.target.value)}
              onFocus={onFocus}
              onBlur={onBlur}
              inputMode="search"
              autoCapitalize="none"
              autoComplete="off"
              spellCheck={false}
              placeholder={activeTab?.incognito ? 'Incognito search or URL' : 'Search Google or type URL'}
              className="h-full min-w-0 flex-1 bg-transparent text-[15px] text-white outline-none placeholder:text-white/35"
            />
            <button type="button" aria-label="Voice search" onMouseDown={(e) => e.preventDefault()} onClick={onVoice} className={`grid h-8 w-8 place-items-center rounded-full transition ${voiceListening ? 'bg-rube-pink text-white shadow-[0_0_20px_rgba(255,79,216,.5)]' : 'bg-white/7 text-white/70'}`}>
              <Icon name="mic" className="h-4 w-4" />
            </button>
          </label>
        </form>
        <button aria-label="AI assistant" onClick={onAI} className="touch-pop grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-rube-cyan/25 to-rube-violet/25 text-rube-cyan shadow-[0_0_22px_rgba(53,245,255,.18)] transition">
          <Icon name="ai" />
        </button>
        <button aria-label="Tabs" onClick={onTabs} className="touch-pop relative grid h-10 w-10 place-items-center rounded-full bg-white/7 text-white/80 transition hover:bg-white/12">
          <Icon name="tabs" />
          <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-rube-violet px-1 text-[10px] font-bold text-white shadow-[0_0_12px_rgba(155,92,255,.8)]">{tabCount}</span>
        </button>
        <button aria-label="Menu" onClick={onMenu} className="touch-pop grid h-10 w-10 place-items-center rounded-full bg-white/7 text-white/80 transition hover:bg-white/12">
          <Icon name="menu" />
        </button>
      </div>
    </header>
  );
}

function SearchSuggestions({ suggestions, onPick }: { suggestions: Array<{ label: string; value: string; type: string }>; onPick: (value: string) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10, scale: .98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8, scale: .98 }}
      className="absolute left-3 right-3 top-[calc(var(--safe-top)+76px)] z-50 max-h-[54dvh] overflow-y-auto rounded-[1.5rem] glass p-2 no-scrollbar md:left-[calc(50%-32rem)] md:right-[calc(50%-32rem)]"
    >
      {suggestions.map((item, index) => (
        <button key={`${item.type}-${item.value}-${index}`} onMouseDown={(event) => event.preventDefault()} onClick={() => onPick(item.value)} className="flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition hover:bg-white/9 active:scale-[.99]">
          <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${item.type === 'ai' ? 'bg-rube-violet/25 text-rube-cyan' : item.type === 'history' ? 'bg-white/7 text-white/60' : 'bg-rube-cyan/12 text-rube-cyan'}`}>
            <Icon name={item.type === 'ai' ? 'ai' : item.type === 'shortcut' ? 'globe' : 'search'} className="h-4 w-4" />
          </span>
          <span className="min-w-0 flex-1 truncate text-sm text-white/88">{item.label}</span>
          <span className="rounded-full bg-white/7 px-2 py-1 text-[10px] uppercase tracking-wide text-white/40">{item.type}</span>
        </button>
      ))}
    </motion.div>
  );
}

function NewTabView({ onNavigate, onAI, history, installed, canInstall, onInstall }: { onNavigate: (input: string) => void; onAI: (prompt: string) => void; history: HistoryEntry[]; installed: boolean; canInstall: boolean; onInstall: () => void }) {
  const [query, setQuery] = useState('');
  const quick = [
    ['YouTube', 'youtube'], ['Google', 'google'], ['News', 'news'], ['GitHub', 'github'], ['Maps', 'maps'], ['Reddit', 'reddit'], ['Wikipedia', 'wikipedia'], ['Amazon', 'amazon']
  ];
  return (
    <div className="min-h-full px-5 pb-8 pt-8 text-white">
      <div className="mx-auto max-w-xl text-center">
        <motion.div className="mx-auto mb-5 grid h-20 w-20 place-items-center rounded-[2rem] bg-gradient-to-br from-rube-cyan via-rube-violet to-rube-pink shadow-[0_0_48px_rgba(53,245,255,.30)]" animate={{ y: [0, -7, 0], rotate: [0, 1.5, -1.5, 0] }} transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}>
          <span className="text-4xl font-black">R</span>
        </motion.div>
        <h1 className="neon-text text-4xl font-black tracking-tight">Rube Browser</h1>
        <p className="mt-2 text-sm text-white/55">Mobile-first browser PWA with tabs, AI, gestures, and futuristic glass UI.</p>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onNavigate(query); }} className="mx-auto mt-7 flex max-w-xl items-center gap-2 rounded-[1.45rem] border border-white/10 bg-black/30 p-2 shadow-inner shadow-black/30">
        <Icon name="search" className="ml-2 h-5 w-5 text-rube-cyan" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search Google or enter a URL" className="h-12 min-w-0 flex-1 bg-transparent text-[16px] outline-none placeholder:text-white/35" />
        <button className="touch-pop rounded-full bg-white px-4 py-3 text-sm font-bold text-slate-950">Go</button>
      </form>

      <div className="mx-auto mt-6 grid max-w-xl grid-cols-4 gap-3">
        {quick.map(([label, value]) => (
          <button key={label} onClick={() => onNavigate(value)} className="touch-pop rounded-[1.25rem] border border-white/10 bg-white/[.06] p-3 text-center transition hover:bg-white/[.10]">
            <span className="mx-auto mb-2 grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-rube-cyan/20 to-rube-violet/20 text-sm font-black">{label[0]}</span>
            <span className="block truncate text-xs text-white/70">{label}</span>
          </button>
        ))}
      </div>

      <div className="mx-auto mt-6 grid max-w-xl gap-3 sm:grid-cols-2">
        <button onClick={() => onAI('Give me the top things I should know today in concise bullets.')} className="glass-light touch-pop rounded-[1.35rem] p-4 text-left">
          <div className="flex items-center gap-3"><Icon name="ai" className="h-5 w-5 text-rube-cyan" /><span className="font-semibold">AI brief</span></div>
          <p className="mt-2 text-xs leading-5 text-white/50">Ask Rube AI for research, page summaries, translations, and commands.</p>
        </button>
        <button onClick={() => onNavigate(searchUrl('latest technology news', 'google'))} className="glass-light touch-pop rounded-[1.35rem] p-4 text-left">
          <div className="flex items-center gap-3"><Icon name="spark" className="h-5 w-5 text-rube-pink" /><span className="font-semibold">Trending search</span></div>
          <p className="mt-2 text-xs leading-5 text-white/50">{trendingSearches.slice(0, 3).join(' • ')}</p>
        </button>
        {!installed && canInstall && (
          <button onClick={onInstall} className="glass-light touch-pop rounded-[1.35rem] p-4 text-left sm:col-span-2">
            <div className="flex items-center gap-3"><Icon name="download" className="h-5 w-5 text-rube-green" /><span className="font-semibold">Install as an app</span></div>
            <p className="mt-2 text-xs leading-5 text-white/50">Add Rube to your home screen for a full-screen PWA experience.</p>
          </button>
        )}
      </div>

      <div className="mx-auto mt-6 max-w-xl rounded-[1.35rem] border border-white/10 bg-black/20 p-4">
        <div className="mb-3 flex items-center justify-between"><h2 className="text-sm font-bold">Recent</h2><span className="text-xs text-white/35">local only</span></div>
        <div className="space-y-2">
          {history.slice(0, 6).map((item) => (
            <button key={item.id} onClick={() => onNavigate(item.url)} className="flex w-full items-center gap-3 rounded-2xl p-2 text-left transition hover:bg-white/7">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-white/7 text-xs">{hostFromUrl(item.url).slice(0, 1).toUpperCase()}</span>
              <span className="min-w-0 flex-1 truncate text-sm text-white/70">{item.title}</span>
            </button>
          ))}
          {!history.length && <p className="py-5 text-center text-sm text-white/35">Your history suggestions will appear here.</p>}
        </div>
      </div>
    </div>
  );
}

function BottomNav({ canGoBack, canGoForward, onBack, onForward, onHome, onNewTab, onTabs }: { canGoBack: boolean; canGoForward: boolean; onBack: () => void; onForward: () => void; onHome: () => void; onNewTab: () => void; onTabs: () => void }) {
  const item = 'touch-pop grid h-12 w-12 place-items-center rounded-full transition';
  return (
    <nav className="pointer-events-none absolute inset-x-0 bottom-0 z-40 px-5 pb-[calc(var(--safe-bottom)+12px)] md:hidden">
      <div className="pointer-events-auto mx-auto flex max-w-md items-center justify-between rounded-[1.75rem] glass p-2">
        <button aria-label="Back" onClick={onBack} className={`${item} ${canGoBack ? 'bg-white/9 text-white' : 'text-white/35'}`}><Icon name="back" /></button>
        <button aria-label="Forward" onClick={onForward} className={`${item} ${canGoForward ? 'bg-white/9 text-white' : 'text-white/35'}`}><Icon name="forward" /></button>
        <button aria-label="Home" onClick={onHome} className={`${item} bg-white/9 text-white`}><Icon name="home" /></button>
        <button aria-label="New tab" onClick={onNewTab} className={`${item} bg-gradient-to-br from-rube-cyan to-rube-violet text-white shadow-[0_0_28px_rgba(53,245,255,.25)]`}><Icon name="plus" /></button>
        <button aria-label="Tabs" onClick={onTabs} className={`${item} bg-white/9 text-white`}><Icon name="tabs" /></button>
      </div>
    </nav>
  );
}

function EmbedHint({ url, onExternal, onSearch }: { url: string; onExternal: () => void; onSearch: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="absolute inset-x-4 bottom-4 rounded-[1.45rem] glass p-4 text-white">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-rube-violet/25 text-rube-cyan"><Icon name="shield" /></div>
        <div className="min-w-0 flex-1">
          <h3 className="font-bold">This site may block embedded browsing</h3>
          <p className="mt-1 text-xs leading-5 text-white/55">Some sites use frame security policies. Rube can still search, save the tab, or open it externally.</p>
          <p className="mt-1 truncate text-[11px] text-white/35">{url}</p>
          <div className="mt-3 flex gap-2">
            <button onClick={onExternal} className="rounded-full bg-white px-4 py-2 text-xs font-bold text-slate-950">Open outside</button>
            <button onClick={onSearch} className="rounded-full bg-white/10 px-4 py-2 text-xs font-bold text-white">Search web</button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function TabsGrid({ tabs, activeTabId, onSelect, onClose, onAdd, onDismiss }: { tabs: BrowserTab[]; activeTabId: string; onSelect: (id: string) => void; onClose: (id: string) => void; onAdd: () => void; onDismiss: () => void }) {
  return (
    <motion.div className="fixed inset-0 z-[70] bg-black/55 p-3 pt-[calc(var(--safe-top)+16px)] backdrop-blur-2xl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="mx-auto flex h-full max-w-4xl flex-col">
        <div className="mb-4 flex items-center justify-between px-1 text-white">
          <div><h2 className="text-2xl font-black">Tabs</h2><p className="text-xs text-white/45">Swipe-like animated cards, saved locally.</p></div>
          <button onClick={onDismiss} className="grid h-11 w-11 place-items-center rounded-full bg-white/10"><Icon name="close" /></button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto pb-24 no-scrollbar">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            <AnimatePresence>
              {tabs.map((tab) => (
                <motion.div key={tab.id} layout initial={{ opacity: 0, scale: .88, y: 28 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: .82, y: 20 }} transition={{ type: 'spring', stiffness: 380, damping: 32 }} className={`group relative overflow-hidden rounded-[1.5rem] border ${tab.id === activeTabId ? 'border-rube-cyan shadow-[0_0_28px_rgba(53,245,255,.22)]' : 'border-white/10'} bg-white/[.06]`}>
                  <button onClick={() => onSelect(tab.id)} className="block w-full p-3 text-left">
                    <div className="aspect-[9/14] overflow-hidden rounded-[1.1rem] bg-gradient-to-br from-[#10172f] via-[#16112c] to-[#050711] p-3">
                      <div className="mb-3 flex items-center gap-2 rounded-full bg-black/25 px-2 py-1 text-[10px] text-white/45"><span className="h-2 w-2 rounded-full bg-rube-green" />{hostFromUrl(tab.url)}</div>
                      <div className="mt-auto flex h-full flex-col justify-end">
                        <div className="text-4xl font-black text-white/20">{hostFromUrl(tab.url).slice(0, 1).toUpperCase()}</div>
                        <div className="mt-2 h-2 w-3/4 rounded bg-white/10" />
                        <div className="mt-2 h-2 w-1/2 rounded bg-white/10" />
                      </div>
                    </div>
                    <div className="mt-3 flex items-center gap-2">
                      {tab.favicon ? <img src={tab.favicon} alt="" className="h-5 w-5 rounded" /> : <Icon name="globe" className="h-4 w-4 text-white/45" />}
                      <span className="min-w-0 flex-1 truncate text-sm font-semibold text-white/80">{tab.incognito ? '🕶 ' : ''}{tab.title}</span>
                    </div>
                    <p className="mt-1 truncate text-[11px] text-white/35">{tab.url}</p>
                  </button>
                  <button onClick={() => onClose(tab.id)} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-black/40 text-white opacity-100 backdrop-blur transition sm:opacity-0 sm:group-hover:opacity-100"><Icon name="close" className="h-4 w-4" /></button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
        <button onClick={onAdd} className="absolute bottom-[calc(var(--safe-bottom)+22px)] left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-gradient-to-r from-rube-cyan to-rube-violet px-6 py-4 font-bold text-white shadow-[0_0_38px_rgba(53,245,255,.28)]"><Icon name="plus" /> New tab</button>
      </div>
    </motion.div>
  );
}

function AIPanel({ chat, prompt, setPrompt, busy, onAsk, onClose, onCommand, onVoice, voiceListening, provider }: { chat: ChatMessage[]; prompt: string; setPrompt: (value: string) => void; busy: boolean; onAsk: (prompt: string) => void; onClose: () => void; onCommand: (command: string) => void; onVoice: () => void; voiceListening: boolean; provider: AiProvider }) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); }, [chat, busy]);
  const quick = ['Summarize this page', 'Translate this page to English', 'Explain selected text', 'Search football news', 'Open YouTube', 'Close tab'];
  return (
    <motion.aside className="fixed inset-0 z-[80] bg-black/45 backdrop-blur-xl md:flex md:justify-end" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div initial={{ y: '100%', x: 0 }} animate={{ y: 0, x: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', stiffness: 310, damping: 34 }} className="absolute bottom-0 left-0 right-0 flex h-[86dvh] flex-col rounded-t-[2rem] glass p-4 text-white md:bottom-3 md:left-auto md:right-3 md:top-3 md:h-auto md:w-[420px] md:rounded-[2rem]">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-rube-cyan/30 to-rube-violet/30 text-rube-cyan"><Icon name="ai" /></div><div><h2 className="font-black">Rube AI</h2><p className="text-xs text-white/45">Provider: {provider}</p></div></div>
          <button onClick={onClose} className="grid h-10 w-10 place-items-center rounded-full bg-white/8"><Icon name="close" /></button>
        </div>
        <div className="mb-3 flex gap-2 overflow-x-auto no-scrollbar">
          {quick.map((item) => <button key={item} onClick={() => item === 'Close tab' || item === 'Open YouTube' || item.startsWith('Search') ? onCommand(item) : onAsk(item)} className="shrink-0 rounded-full border border-white/10 bg-white/7 px-3 py-2 text-xs text-white/70">{item}</button>)}
        </div>
        <div ref={scrollRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto rounded-[1.25rem] bg-black/20 p-3 no-scrollbar">
          {chat.map((message) => (
            <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[86%] whitespace-pre-wrap rounded-[1.2rem] px-4 py-3 text-sm leading-6 ${message.role === 'user' ? 'bg-rube-cyan text-slate-950' : 'bg-white/8 text-white/80'}`}>{message.content}</div>
            </div>
          ))}
          {busy && <div className="rounded-[1.2rem] bg-white/8 px-4 py-3 text-sm text-white/55"><span className="animate-pulse">Rube AI is thinking…</span></div>}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); onAsk(prompt); }} className="mt-3 flex items-center gap-2 rounded-[1.3rem] border border-white/10 bg-black/25 p-2">
          <button type="button" onClick={onVoice} className={`grid h-11 w-11 place-items-center rounded-full ${voiceListening ? 'bg-rube-pink text-white' : 'bg-white/8 text-white/70'}`}><Icon name="mic" /></button>
          <input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Ask, translate, summarize, or command…" className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-white/35" />
          <button disabled={busy || !prompt.trim()} className="touch-pop rounded-full bg-white px-4 py-3 text-sm font-bold text-slate-950 disabled:opacity-40">Send</button>
        </form>
      </motion.div>
    </motion.aside>
  );
}

function SettingsSheet({ settings, setSettings, onClose, onClear }: { settings: BrowserSettings; setSettings: React.Dispatch<React.SetStateAction<BrowserSettings>>; onClose: () => void; onClear: () => void }) {
  const row = 'flex items-center justify-between gap-3 rounded-2xl bg-white/[.055] p-3';
  return (
    <motion.div className="fixed inset-0 z-[85] bg-black/50 p-3 pt-[calc(var(--safe-top)+16px)] backdrop-blur-xl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} className="mx-auto flex max-h-full max-w-xl flex-col rounded-[2rem] glass p-4 text-white">
        <div className="mb-4 flex items-center justify-between"><div><h2 className="text-2xl font-black">Settings</h2><p className="text-xs text-white/45">Theme, privacy, AI, and PWA behavior.</p></div><button onClick={onClose} className="grid h-11 w-11 place-items-center rounded-full bg-white/8"><Icon name="close" /></button></div>
        <div className="space-y-3 overflow-y-auto pb-2 no-scrollbar">
          <label className={row}><span>Theme</span><select value={settings.theme} onChange={(e) => setSettings((s) => ({ ...s, theme: e.target.value as ThemeMode }))} className="rounded-xl bg-black/35 px-3 py-2 outline-none">{['dark', 'midnight', 'aurora', 'light'].map((x) => <option key={x}>{x}</option>)}</select></label>
          <label className={row}><span>Search engine</span><select value={settings.searchEngine} onChange={(e) => setSettings((s) => ({ ...s, searchEngine: e.target.value as SearchEngine }))} className="rounded-xl bg-black/35 px-3 py-2 outline-none">{['google', 'duckduckgo', 'bing'].map((x) => <option key={x}>{x}</option>)}</select></label>
          <label className="block rounded-2xl bg-white/[.055] p-3"><span className="mb-2 block">Homepage</span><input value={settings.homepage} onChange={(e) => setSettings((s) => ({ ...s, homepage: e.target.value }))} className="w-full rounded-xl bg-black/35 px-3 py-3 outline-none" /></label>
          <label className={row}><span>Font size</span><input type="range" min="0.88" max="1.18" step="0.01" value={settings.fontScale} onChange={(e) => setSettings((s) => ({ ...s, fontScale: Number(e.target.value) }))} /></label>
          <label className={row}><span>Animation intensity</span><input type="range" min="0" max="1.4" step="0.05" value={settings.animationIntensity} onChange={(e) => setSettings((s) => ({ ...s, animationIntensity: Number(e.target.value) }))} /></label>
          <Toggle label="Incognito by default" checked={settings.privacyMode} onChange={(v) => setSettings((s) => ({ ...s, privacyMode: v }))} />
          <Toggle label="Popup blocker simulation" checked={settings.blockPopups} onChange={(v) => setSettings((s) => ({ ...s, blockPopups: v }))} />
          <label className={row}><span>AI provider</span><select value={settings.aiProvider} onChange={(e) => setSettings((s) => ({ ...s, aiProvider: e.target.value as AiProvider }))} className="rounded-xl bg-black/35 px-3 py-2 outline-none">{['demo', 'groq', 'openai', 'gemini'].map((x) => <option key={x}>{x}</option>)}</select></label>
          <label className="block rounded-2xl bg-white/[.055] p-3"><span className="mb-2 block">AI model override</span><input value={settings.aiModel || ''} onChange={(e) => setSettings((s) => ({ ...s, aiModel: e.target.value }))} placeholder="Optional" className="w-full rounded-xl bg-black/35 px-3 py-3 outline-none placeholder:text-white/30" /></label>
          <label className="block rounded-2xl bg-white/[.055] p-3"><span className="mb-2 block">Client API key (optional)</span><input type="password" value={settings.aiApiKey || ''} onChange={(e) => setSettings((s) => ({ ...s, aiApiKey: e.target.value }))} placeholder="Prefer server .env keys for production" className="w-full rounded-xl bg-black/35 px-3 py-3 outline-none placeholder:text-white/30" /><p className="mt-2 text-xs text-white/40">Production apps should use server-side env keys. Client keys stay in localStorage on this device.</p></label>
          <button onClick={onClear} className="w-full rounded-2xl border border-red-400/30 bg-red-500/10 p-4 font-bold text-red-100">Clear history, cache data, tabs & chat</button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className="flex w-full items-center justify-between gap-3 rounded-2xl bg-white/[.055] p-3 text-left">
      <span>{label}</span>
      <span className={`relative h-7 w-12 rounded-full transition ${checked ? 'bg-rube-cyan' : 'bg-white/15'}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition ${checked ? 'left-6' : 'left-1'}`} /></span>
    </button>
  );
}

function DownloadsSheet({ downloads, setDownloads, onClose }: { downloads: DownloadItem[]; setDownloads: React.Dispatch<React.SetStateAction<DownloadItem[]>>; onClose: () => void }) {
  const toggle = (id: string) => setDownloads((items) => items.map((item) => item.id === id ? { ...item, state: item.state === 'paused' ? 'downloading' : item.state === 'downloading' ? 'paused' : item.state } : item));
  return (
    <motion.div className="fixed inset-0 z-[84] bg-black/50 p-3 pt-[calc(var(--safe-top)+16px)] backdrop-blur-xl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} className="mx-auto flex max-h-full max-w-xl flex-col rounded-[2rem] glass p-4 text-white">
        <div className="mb-4 flex items-center justify-between"><div><h2 className="text-2xl font-black">Downloads</h2><p className="text-xs text-white/45">Simulated download manager for web/PWA UX.</p></div><button onClick={onClose} className="grid h-11 w-11 place-items-center rounded-full bg-white/8"><Icon name="close" /></button></div>
        <div className="space-y-3 overflow-y-auto no-scrollbar">
          {downloads.map((item) => (
            <div key={item.id} className="rounded-2xl bg-white/[.055] p-3">
              <div className="flex items-center gap-3"><Icon name="download" className="h-5 w-5 text-rube-cyan" /><div className="min-w-0 flex-1"><p className="truncate font-semibold">{item.filename}</p><p className="truncate text-xs text-white/40">{item.url}</p></div><button onClick={() => toggle(item.id)} className="rounded-full bg-white/10 px-3 py-1 text-xs capitalize">{item.state === 'downloading' ? 'pause' : item.state === 'paused' ? 'resume' : item.state}</button></div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-black/25"><div className="h-full rounded-full bg-gradient-to-r from-rube-cyan to-rube-violet" style={{ width: `${item.progress}%` }} /></div>
            </div>
          ))}
          {!downloads.length && <p className="py-10 text-center text-sm text-white/35">No downloads yet.</p>}
        </div>
      </motion.div>
    </motion.div>
  );
}

function MenuSheet({ onClose, onSettings, onDownloads, onInstall, canInstall, installed, onNewIncognito, onDownload, onExternal, currentUrl }: { onClose: () => void; onSettings: () => void; onDownloads: () => void; onInstall: () => void; canInstall: boolean; installed: boolean; onNewIncognito: () => void; onDownload: () => void; onExternal: () => void; currentUrl: string }) {
  const actions = [
    { icon: 'shield', label: 'New incognito tab', action: onNewIncognito },
    { icon: 'download', label: 'Download page', action: onDownload },
    { icon: 'download', label: 'Downloads', action: onDownloads },
    { icon: 'settings', label: 'Settings', action: onSettings },
    { icon: 'external', label: 'Open current externally', action: onExternal, disabled: !currentUrl || currentUrl === 'rube://newtab' }
  ];
  return (
    <motion.div className="fixed inset-0 z-[82] bg-black/40 backdrop-blur-xl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.div onClick={(e) => e.stopPropagation()} initial={{ y: 280 }} animate={{ y: 0 }} exit={{ y: 280 }} transition={{ type: 'spring', stiffness: 340, damping: 34 }} className="absolute bottom-0 left-0 right-0 rounded-t-[2rem] glass p-4 pb-[calc(var(--safe-bottom)+18px)] text-white md:left-1/2 md:right-auto md:w-[420px] md:-translate-x-1/2 md:rounded-[2rem]">
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-white/20" />
        <div className="grid grid-cols-2 gap-3">
          {!installed && canInstall && <button onClick={onInstall} className="col-span-2 flex items-center gap-3 rounded-2xl bg-gradient-to-r from-rube-cyan/25 to-rube-violet/25 p-4 text-left"><Icon name="download" className="text-rube-cyan" /><span className="font-bold">Install Rube PWA</span></button>}
          {actions.map((item) => <button key={item.label} disabled={item.disabled} onClick={item.action} className="flex items-center gap-3 rounded-2xl bg-white/[.06] p-4 text-left disabled:opacity-35"><Icon name={item.icon} className="h-5 w-5 text-rube-cyan" /><span className="text-sm font-semibold">{item.label}</span></button>)}
        </div>
        <div className="mt-4 rounded-2xl border border-white/10 bg-black/20 p-4 text-xs leading-5 text-white/45">
          <strong className="text-white/70">Safe browsing note:</strong> Rube runs inside browser security boundaries. Sandboxed frames, local-only history, incognito simulation, popup controls, and external-open fallbacks are included.
        </div>
      </motion.div>
    </motion.div>
  );
}
