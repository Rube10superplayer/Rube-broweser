import type { SearchEngine } from '../types/browser';

const engineUrls: Record<SearchEngine, (q: string) => string> = {
  google: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
  duckduckgo: (q) => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
  bing: (q) => `https://www.bing.com/search?q=${encodeURIComponent(q)}`
};

const shortcuts: Record<string, string> = {
  youtube: 'https://www.youtube.com',
  yt: 'https://www.youtube.com',
  gmail: 'https://mail.google.com',
  google: 'https://www.google.com',
  maps: 'https://maps.google.com',
  twitter: 'https://x.com',
  x: 'https://x.com',
  instagram: 'https://www.instagram.com',
  reddit: 'https://www.reddit.com',
  github: 'https://github.com',
  netflix: 'https://www.netflix.com',
  amazon: 'https://www.amazon.com',
  news: 'https://news.google.com',
  wikipedia: 'https://www.wikipedia.org'
};

export function isProbablyUrl(input: string) {
  const value = input.trim();
  if (!value) return false;
  if (/^(https?:\/\/|file:|data:)/i.test(value)) return true;
  if (/\s/.test(value)) return false;
  return /^([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?(\/.*)?$/i.test(value) || /^localhost(:\d+)?(\/.*)?$/i.test(value);
}

export function normalizeNavigation(input: string, engine: SearchEngine = 'google') {
  const value = input.trim();
  if (!value) return 'rube://newtab';
  const shortcut = shortcuts[value.toLowerCase()];
  if (shortcut) return shortcut;
  if (isProbablyUrl(value)) return /^(https?:)?\/\//i.test(value) ? value : `https://${value}`;
  return engineUrls[engine](value);
}

export function hostFromUrl(url: string) {
  try {
    if (url.startsWith('rube://')) return 'Rube';
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

export function faviconFor(url: string) {
  try {
    const host = new URL(url).origin;
    return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=64`;
  } catch {
    return undefined;
  }
}

export function searchUrl(query: string, engine: SearchEngine = 'google') {
  return engineUrls[engine](query);
}

export const trendingSearches = [
  'latest AI news',
  'football news today',
  'best Android phones',
  'space exploration updates',
  'weather near me',
  'open source browser engines'
];

export function makeSuggestions(input: string, recent: string[] = []) {
  const q = input.trim().toLowerCase();
  const base = [
    ...Object.keys(shortcuts).map((name) => ({ label: name, value: shortcuts[name], type: 'shortcut' })),
    ...trendingSearches.map((item) => ({ label: item, value: item, type: 'trend' })),
    ...recent.map((item) => ({ label: item, value: item, type: 'history' }))
  ];
  if (!q) return base.slice(0, 8);
  const dynamic = [
    { label: `Search Google for “${input}”`, value: input, type: 'search' },
    { label: `AI answer: ${input}`, value: `ai:${input}`, type: 'ai' }
  ];
  return [...dynamic, ...base.filter((x) => x.label.toLowerCase().includes(q) || x.value.toLowerCase().includes(q))].slice(0, 9);
}
