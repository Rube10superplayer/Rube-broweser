import RubeBrowserMobile from './components/RubeBrowserMobile';

export default function Home() {
  return <RubeBrowserMobile />;
}
