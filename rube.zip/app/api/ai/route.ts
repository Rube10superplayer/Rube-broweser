import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

type Provider = 'demo' | 'groq' | 'openai' | 'gemini';

type IncomingMessage = { role: 'user' | 'assistant' | 'system'; content: string };

function demoResponse(prompt: string, url?: string) {
  const focus = url ? ` for ${url}` : '';
  return [
    `I’m Rube AI running in local demo mode${focus}.`,
    '',
    'What I can do now:',
    '• Turn natural language into browser actions like “open YouTube” or “search football news”.',
    '• Summarize the current page when same-origin text is available, or summarize from pasted/selected text.',
    '• Translate, explain, and rewrite content when you connect Groq, OpenAI, or Gemini.',
    '',
    `Your request: “${prompt.slice(0, 420)}”`
  ].join('\n');
}

async function callOpenAICompatible(endpoint: string, apiKey: string, model: string, messages: IncomingMessage[]) {
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({ model, messages, temperature: 0.45, max_tokens: 900 })
  });
  if (!response.ok) throw new Error(await response.text());
  const data = await response.json();
  return data.choices?.[0]?.message?.content ?? 'No AI response returned.';
}

async function callGemini(apiKey: string, model: string, messages: IncomingMessage[]) {
  const prompt = messages.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.45, maxOutputTokens: 900 }
    })
  });
  if (!response.ok) throw new Error(await response.text());
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? '').join('') ?? 'No AI response returned.';
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const provider = (body.provider ?? 'demo') as Provider;
    const apiKey = body.apiKey ||
      (provider === 'groq' ? process.env.GROQ_API_KEY : undefined) ||
      (provider === 'openai' ? process.env.OPENAI_API_KEY : undefined) ||
      (provider === 'gemini' ? process.env.GEMINI_API_KEY : undefined);

    const prompt = String(body.prompt ?? '');
    const url = body.url ? String(body.url) : undefined;
    const pageText = body.pageText ? String(body.pageText).slice(0, 12000) : '';
    const system = [
      'You are Rube AI, a concise premium mobile browser assistant.',
      'Help with browsing, summarization, translation, safe search, and browser commands.',
      'If page text is missing, explain that cross-origin browser security may prevent reading iframe contents.',
      url ? `Current URL: ${url}` : '',
      pageText ? `Available page text:\n${pageText}` : ''
    ].filter(Boolean).join('\n');

    const messages: IncomingMessage[] = [
      { role: 'system', content: system },
      ...(Array.isArray(body.messages) ? body.messages.slice(-8).map((m: IncomingMessage) => ({ role: m.role, content: String(m.content).slice(0, 4000) })) : []),
      { role: 'user', content: prompt }
    ];

    if (provider === 'demo' || !apiKey) {
      return NextResponse.json({ text: demoResponse(prompt, url), provider: 'demo' });
    }

    let text = '';
    if (provider === 'groq') {
      text = await callOpenAICompatible('https://api.groq.com/openai/v1/chat/completions', apiKey, body.model || process.env.GROQ_MODEL || 'llama-3.3-70b-versatile', messages);
    } else if (provider === 'openai') {
      text = await callOpenAICompatible('https://api.openai.com/v1/chat/completions', apiKey, body.model || process.env.OPENAI_MODEL || 'gpt-4o-mini', messages);
    } else if (provider === 'gemini') {
      text = await callGemini(apiKey, body.model || process.env.GEMINI_MODEL || 'gemini-1.5-flash', messages);
    }

    return NextResponse.json({ text, provider });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'AI request failed' }, { status: 500 });
  }
}
