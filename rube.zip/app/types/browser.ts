export type SearchEngine = 'google' | 'duckduckgo' | 'bing';
export type ThemeMode = 'dark' | 'midnight' | 'aurora' | 'light';
export type AiProvider = 'demo' | 'groq' | 'openai' | 'gemini';

export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  canGoBack: boolean;
  canGoForward: boolean;
  createdAt: number;
  updatedAt: number;
  incognito?: boolean;
  loading?: boolean;
  progress?: number;
  backStack?: string[];
  forwardStack?: string[];
}


export interface HistoryEntry {
  id: string;
  title: string;
  url: string;
  visitedAt: number;
}

export interface DownloadItem {
  id: string;
  filename: string;
  url: string;
  progress: number;
  state: 'queued' | 'downloading' | 'paused' | 'complete' | 'failed';
  createdAt: number;
}

export interface BrowserSettings {
  theme: ThemeMode;
  searchEngine: SearchEngine;
  homepage: string;
  fontScale: number;
  animationIntensity: number;
  privacyMode: boolean;
  blockPopups: boolean;
  aiProvider: AiProvider;
  aiApiKey?: string;
  aiModel?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
}
