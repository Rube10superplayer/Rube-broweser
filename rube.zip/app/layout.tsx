import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });

export const metadata: Metadata = {
  title: 'Rube Browser Mobile',
  description: 'A futuristic mobile-first browser-in-browser PWA with AI, tabs, gestures, and glassmorphism UI.',
  applicationName: 'Rube Browser',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Rube Browser'
  },
  manifest: '/manifest.webmanifest',
  icons: {
    icon: '/icons/icon.svg',
    apple: '/icons/maskable.svg'
  }
};

export const viewport: Viewport = {
  themeColor: '#050711',
  colorScheme: 'dark',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} min-h-screen bg-rube-bg text-white antialiased`}>{children}</body>
    </html>
  );
}
